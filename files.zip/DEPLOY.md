# Deploying teamvconstructiongroup.com on GitHub Pages

Everything in this folder is the **repo root**. Do not nest it in a subfolder.

## 1. Create the repo

1. github.com → **New repository**
2. Name: `teamvconstructiongroup.com` (any name works — the domain comes from the CNAME file)
3. Visibility: **Public** (Pages requires a paid plan for private repos)
4. Do NOT add a README, .gitignore, or license
5. Create repository

## 2. Upload these files

On the empty repo page → **uploading an existing file** → drag in the
*contents* of this folder (index.html, styles.css, gallery.js, 404.html,
CNAME, robots.txt, sitemap.xml, favicon.ico, the icons, and the
`assets/` and `services/` folders). Commit.

Verify after upload: `index.html` and `CNAME` must sit at the top level of
the repo, not inside a folder.

Note: `.nojekyll` is a hidden file and the browser upload may skip it.
If it does, create it manually: **Add file → Create new file**, name it
`.nojekyll`, leave it empty, commit.

## 3. Turn on Pages

Repo → **Settings** → **Pages**
- Source: *Deploy from a branch*
- Branch: `main` / folder `/ (root)` → **Save**

The Custom domain field will auto-populate with
`www.teamvconstructiongroup.com` from the CNAME file. It will show an
error until DNS is live — that is expected.

## 4. DNS in Squarespace

Google Admin console → Domains → teamvconstructiongroup.com →
**MANAGE DOMAIN (via Squarespace)** → DNS settings.

**Delete first:** any existing A record on `@` (root/blank host), and any
Squarespace parking or default records.

**Then add:**

| Type  | Host | Value                    |
|-------|------|--------------------------|
| CNAME | www  | YOUR-GITHUB-USERNAME.github.io |
| A     | @    | 185.199.108.153          |
| A     | @    | 185.199.109.153          |
| A     | @    | 185.199.110.153          |
| A     | @    | 185.199.111.153          |

Replace `YOUR-GITHUB-USERNAME` with the account or organization that owns
the repo — it is the name in your repo URL, `github.com/<name>/<repo>`.
Enter it as `name.github.io` only: no `https://`, no repo name, no
trailing slash or path.

**Do not touch:** MX records, or TXT records starting with `v=spf1` or
named `google._domainkey`. Those are your Gmail and email
authentication. Deleting MX takes your email offline.

**Skip** the Google Admin "Change redirect" screen entirely. It is
HTTP-only and GitHub handles the apex-to-www redirect with a real
certificate.

## 5. Finish (30-60 min later)

Repo → Settings → Pages → refresh. Green check on the domain, then tick
**Enforce HTTPS**. If the box is greyed out, the certificate is still
issuing — wait, then re-check. Still stuck after a few hours: clear the
Custom domain field, Save, re-enter it, Save.

## 6. After it is live

- Google Search Console → add property `https://www.teamvconstructiongroup.com`
  → submit `https://www.teamvconstructiongroup.com/sitemap.xml`
- Link the site from your Google Business Profile and LinkedIn
- Test the share preview: paste the URL into LinkedIn's post composer and
  confirm the og-image renders

## What changed from the v4 package

- `CNAME` → binds the repo to www.teamvconstructiongroup.com
- `.nojekyll` → skips Jekyll processing, faster and avoids surprises
- Canonical URLs on all 7 pages → prevents `/index.html` vs `/` duplicate
  indexing
- Open Graph + Twitter Card tags → link previews on LinkedIn, iMessage,
  Slack, Facebook
- `assets/og-image.jpg` → 1200x630 share image cropped from the hero
- `GeneralContractor` JSON-LD on the homepage → CSLB license numbers,
  San Marcos address, and service list in machine-readable form for local
  search
- Favicons: `favicon.ico`, `icon-192.png`, `icon-512.png`,
  `apple-touch-icon.png`
- `robots.txt` + `sitemap.xml` with absolute URLs
- `404.html` styled to match the site
- Hero image converted from a 3.0 MB PNG to a 336 KB progressive JPEG
  (~89% smaller, no visible difference on a photo) and the two CSS
  references updated
- Truncated service-page meta descriptions closed off cleanly

## Local preview

Relative paths are preserved, so opening `index.html` directly in a
browser works. For an exact match to production:

    python3 -m http.server 8000

then visit http://localhost:8000
